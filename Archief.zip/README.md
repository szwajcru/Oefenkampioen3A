# Woordrijen Toets (inline Ankers in HTML)

- **Intro pagina** toont keuze van Anker via verticale radio buttons.
- Woorden per Anker zijn direct in de HTML opgenomen (geen fetch nodig).
- Alleen Anker 1 bevat nu woorden, Anker 2 en 3 zijn leeg.
- Geschikt om direct te openen via dubbelklik op index.html.

## Gebruik
Open `index.html` in een browser.
